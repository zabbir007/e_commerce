@extends('layouts.user')

@section('title') User Dashboard @endsection

@section('content')

@endsection
