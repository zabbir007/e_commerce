@extends('layouts.supplier')

@section('title') Supplier Dashboard @endsection

@section('content')

@endsection
